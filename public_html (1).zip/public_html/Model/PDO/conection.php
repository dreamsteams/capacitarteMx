<?php namespace Model\PDO;
  class Conexion{
        public $Servidor='mysql:host=localhost;dbname=cursos-capacitarte';
        public $Usuario="capacitarte";
        public $Pass="eldepto!@";

 }


?>
